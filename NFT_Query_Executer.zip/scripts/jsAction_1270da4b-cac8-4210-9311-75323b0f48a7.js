﻿// Javascript to create a file.

//Path has been set in the constant Variable: fileDirPath
var dirPath = context.variableManager.getValue("fileDirPath");

//Each user path need to give unique output file name
var fileName=dirPath+"002_Business_Partner_Profile_Create"+".txt"

//Getting the total count of the execute query
var reCount = context.variableManager.getValue("tcQueryOutput_matchNr");
var lock = new java.util.concurrent.locks.ReentrantLock();

//Function to create a file, and write the content based on the variable.
function writeFile() {
    lock.lock();
    var writer = new java.io.FileWriter(fileName, true);
    for (var incNum = 1; incNum <= reCount; incNum++) {
        var recValue = context.variableManager.getValue("tcQueryOutput_"+incNum);
        writer.write(recValue);
        writer.write("\n");
    }
    
    writer.close();
    lock.unlock();
}

//Main function calling
writeFile();