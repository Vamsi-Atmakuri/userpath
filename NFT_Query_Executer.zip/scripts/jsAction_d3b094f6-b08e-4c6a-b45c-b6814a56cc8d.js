﻿// Javascript to create a file.

//Path has been set in the constant Variable: fileDirPath
var dirPath = context.variableManager.getValue("fileDirPath");

//Each user path need to give unique output file name
var fileName=dirPath+"010_Quotations_Customer_Contracts_002_View"+"_Failure"+".txt"

var lock = new java.util.concurrent.locks.ReentrantLock();

//Function to create a file, and write the content based on the variable.
function writeFile() {
    lock.lock();
    var writer = new java.io.FileWriter(fileName, true);
    writer.write("No Records are aviable for this criteria, Need to revist the query. ");
    
    writer.close();
    lock.unlock();
}

//Main function calling
writeFile();